

const mongoose = require('mongoose');

const postSchema = new mongoose.Schema({

    fname:{
        type:String,
        required:true
    },

    
    lname:{
        type:String,
        required:true
    },

    email:{
        type:String,
        required:true
    },

    password:{
        type:String,
        required:true
    },

    city:{
        type:String,
        required:true
    },

    country:{
        type:String,
        required:true
    },

    phone:{
        type:String,
        required:true
    }

});

module.exports = mongoose.model('Register', postSchema);






