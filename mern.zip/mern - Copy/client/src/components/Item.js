import React, {useState, useEffect} from 'react'
import styled from 'styled-components'
import axios from 'axios'
import spinner from '../spinner.gif'
import {Link} from 'react-router-dom'


export const Item = props => {
    const [name, setName] = useState('')
    const [description, setDescription] = useState('')
    const [price, setPrice] = useState('')
    const [fileName, setFileName] = useState('')

    useEffect(() => {
        axios.get(`/items/${props.match.params.id}`)
        .then((response) => [
            setName(response.data.name),
            setDescription(response.data.description),
            setPrice(response.data.price),
            setFileName(response.data.itemImage)
        ])
        .catch(error => console.log(error));
    }, [])
    
    
    
return (
        <MainContainer>
            {!name || !description || !price ? <img src={spinner} alt="loading..."/> :
        <>
        <img src={`/uploads/${fileName}`} alt="..."
        style={{ margin: "0 auto", width: "30%", display: "flex"}}></img>
        <h2>{name}</h2>
        <p className="des">{description}</p>
        <p className="price"><h2>{price}</h2></p>
        <br/>
        <Link to="/"
            type="submit" className="btn btn-primary" ><h5>
                Back To Home</h5></Link>
        </>
        }
        </MainContainer>
        
        );
};

export default Item

//MAIN CONTAINER 
const MainContainer = styled.div`
    margin: 2rem ;
    padding: 3rem 14rem;

    h2 {
        text-align: center;
        margin-top: 2rem;
        font-weight: 900;
        color: #1D2951;
    }

    p .des {
        text-align: center;
        font-weight: 400;
        color: #1D2951;
    }

    .price h2 {
        color: red;
        text-align: center;
        font-weight: 400;
    }

    img {
        
        display: block;
        margin: auto;
    }

    .btn-primary {
        margin-top: 2rem;
        margin-left:15rem;
        width:15rem;
        height: 3rem;
        background: #1D2951;
        border: none;
        &:hover {
            background: #23387F;
        }
    
    `;
