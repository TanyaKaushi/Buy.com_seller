
import React, {useState} from 'react';
import styled from 'styled-components';
import spinner from "../spinner.gif";
import {Link} from "react-router-dom";
import axios from "axios";

const Home = ({posts}) => {
    const [item, setItem] = useState([])


    return (
        <MainContainer >

       <h1>Home</h1>
      
       <Link  className="nav-link" to="/register">Sign Up</Link >
        </MainContainer >
    ); 
};

export default Home;

// MAIN CONTAINER

const MainContainer = styled.div`
    margin: 2rem 0;

    img {
        width: 10rem;
        display: block;
        margin: auto;
        margin-top:3rem;
        margin-botton: 4rem;
    }


    span h2{
        color: red;
        font-weight: 500;
        margin-top:2rem;
    }


    .card {
        color: #02014b ;
       background: #FFFFFF;
    }

    h2 {
        margin-top: 5rem;
        color: #02014b ;
        font-weight: 400;
    }

    .btn btn-outline-danger {
        margin-left:2rem;
    }

    
    .card {
        margin: auto;
    }
`;