import React, {useState, useEffect} from 'react'
import styled from 'styled-components'
import axios from 'axios'

export const EditItem = props => {
    const [name, setName] = useState("")
    const [description, setDescription] = useState("")
    const [price, setPrice] = useState("");
    const [message, setMessage] = useState("")
    const [fileName, setFileName] = useState("")


    const onChangeFile = e => {
        setFileName(e.target.files[0]);
    }



    const changeOnClick = e => {
       e.preventDefault();

 

    const formData = new FormData();

    formData.append("name", name);
    formData.append("description", description);
    formData.append("price", price);
    formData.append("itemImage", fileName);


       setName("");
       setDescription("");
       setPrice("");


       axios.put(`/items/update/${props.match.params.id}`, formData )
       .then(res => setMessage(res.data))
       .catch(err => {
           console.log(err);
       });
    };

        
    useEffect(() => {
        axios.get(`/items/${props.match.params.id}`)
        .then(res => [
            setName(res.data.name),
            setDescription(res.data.description),
            setPrice(res.data.price),
            setFileName(res.data.itemImage)
        ])
        .catch(error => console.log(error))
    }, [])
    


    return (
     <AddItemContainer>
        <div className="container">
         <h1>Update Item</h1>
         <span className="message">{message}</span>
            <form onSubmit={changeOnClick} encType="multipart/form-data">
            <div className="form-group">
                 <label htmlFor="price" >Price</label>
                <input type="text" 
                value={price}
                onChange={e => setPrice(e.target.value)}
                className="form-control"
                placeholder="Item Price">
                    </ input>
            </div>

            <div className="form-group">
                <label htmlFor="name" >Name</label>
                <input type="text" 
                value={name}
                onChange={e => setName(e.target.value)}
                className="form-control" 
                placeholder="Item Name">

                </input>
            </div>

            <div className="form-group">
                <label htmlFor="description"> description</label>
                <textarea  
                value={description}
                onChange={e => setDescription(e.target.value)}
                className="form-control" rows="3">
                </textarea>
                </div>

                <div className="form-group">
                    <label htmlFor="file">Choose item image</label>
                    <input type="file" filename="itemImage" className="form-control-file"
                    onChange={onChangeFile}></input>
                </div>

            <button 
            type="submit" className="btn btn-primary">
                Update Article</button>
            </form>
    </div>
</AddItemContainer>
)}

export default EditItem

//MAIN CONTAINER
const AddItemContainer = styled.div`
    margin: 4rem auto;
    width: 32rem;

    h1 {
        font-weight: 900;;
        color: #02014b ;
    }

    .form-group {
        margin: 1rem auto;
    }

    .btn-primary {
        margin-top: 2rem;
        background: #02014b ;
        border: none;
        &:hover {
            background: #23387F;
        }
    }

    .message {
        font-weight: 900;
        color: tomato;
        padding: 1rem 1rem 1rem 0;
    }
`;