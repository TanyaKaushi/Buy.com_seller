import React from 'react';
import styled from 'styled-components';
import {Link} from "react-router-dom";
import logo from '../../logo.png';

export const Navbar = () => {
    return (
        <NavbarContaier>
            <nav className="navbar navbar-expand-lg navbar-light px-5 py-0" >
    <Link className="navbar-brand" href="#">
        <img style={{width: "50px"}} src={logo} alt="logo"></img>
    </Link>
    <button 
    className="navbar-toggler" 
    type="button" 
    data-bs-toggle="collapse" 
    data-bs-target="#navbarSupportedContent" 
    aria-controls="navbarSupportedContent" 
    aria-expanded="false" 
    aria-label="Toggle navigation">
      <span className="navbar-toggler-icon"></span>
    </button>
    <div className="collapse navbar-collapse" id="navbarSupportedContent">
      <ul className="navbar-nav ml-auto" >
        <li className="nav-item active">
          <Link  className="nav-link active" aria-current="page" to="/"> Home</Link >
        </li>
        <li className="nav-item">
          <Link  className="nav-link" to="/add-item">Add Article</Link >
        </li>
      </ul>
    </div>
</nav>
</NavbarContaier>
    )
};

export default Navbar;

//MAIN NAVBAR CONTAINER
const NavbarContaier = styled.div`
    background: #1D2951 ;
    height: 3rem;
    .nav-link {
        color: #fff !important;
        &:hover {
            background: #ADD8E6;
            height: 3rem;
            boarder-radius:3rem;
        }
    }


    .nav-link {
      font-weight: 900;
       color: #ADD8E6;
       margin-left: 3rem;
     }
`;
 