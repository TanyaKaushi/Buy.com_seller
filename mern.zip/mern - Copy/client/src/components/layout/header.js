import React from 'react'
import styled from 'styled-components';

const Header = () => {
    return (
        < MainContainer>
          <h1>Welcome to Online Shopping</h1>  
        </ MainContainer>

    )
}

export default Header

//MAIN CONTAINER
const MainContainer = styled.header`
    background: url(../../images/1.JPEG)no-repeat center/cover;
    height: 25rem;

    h1 {
        transform: translate(-50%, -50%);
        color:  #1D2951 ;
        font-weight:900;
        position: absolute;
        top: 30%;
        left: 30%;

    }
    `;