import React, {useState} from 'react';
import styled from 'styled-components';
import axios from 'axios';
import {Link} from "react-router-dom";


export const Register = () => {
    const [fname, setFname] = useState("");
    const [lname, setLname] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [city, setCity] = useState("");
    const [country, setCountry] = useState("");
    const [phone, setPhone] = useState("");
    const [message, setMessage] = useState("");
    

    const changeOnClick = e => {
       e.preventDefault();

    const formData = new FormData();

    formData.append("fname", fname);
    formData.append("lname", lname);
    formData.append("email", email);
    formData.append("password", password);
    formData.append("city", city);
    formData.append("country", country);
    formData.append("phone", phone);
 

       setFname("");
       setLname("");
       setEmail("");
       setPassword("");
       setCity("");
       setCountry("");
       setPhone("");

       axios.post("/register/save", formData)
       .then((res) => setMessage(res.data))
       .catch((err) => {
           console.log(err);
       });
    };

    return (
     <AddItemContainer>
        <div className="container">
         <h1>Sign Up</h1>
         <span className="message">{message}</span>
            <form onSubmit={changeOnClick} encType="multipart/form-data">
            <div className="form-group">
                <label htmlFor="fname" >First Name</label>
                <input type="text" 
                value={fname}
                onChange={e => setFname(e.target.value)}
                className="form-control"
                placeholder="First Name">
                    </ input>
            </div>

            <div className="form-group">
                <label htmlFor="lname" >Last Name</label>
                <input type="text" 
                value={lname}
                onChange={e => setLname(e.target.value)}
                className="form-control" 
                placeholder="Last Name">

                </input>
            </div>


            <div className="form-group">
                <label htmlFor="email" >Email Adddress</label>
                <input type="text" 
                value={email}
                onChange={e => setEmail(e.target.value)}
                className="form-control"
                placeholder="Email Address">
                    </ input>
            </div>

            <div className="form-group">
                <label htmlFor="password" >Password</label>
                <input type="text" 
                value={password}
                onChange={e => setPassword(e.target.value)}
                className="form-control" 
                placeholder="Password">

                </input>
            </div>


            <div className="form-group">
                <label htmlFor="city" >City</label>
                <input type="text" 
                value={city}
                onChange={e => setCity(e.target.value)}
                className="form-control"
                placeholder="City">
                    </ input>
            </div>

            <div className="form-group">
                <label htmlFor="country" >Country</label>
                <input type="text" 
                value={country}
                onChange={e => setCountry(e.target.value)}
                className="form-control" 
                placeholder="Country">

                </input>
            </div>

            <div className="form-group">
                <label htmlFor="phone" >Phone Number</label>
                <input type="text" 
                value={phone}
                onChange={e => setPhone(e.target.value)}
                className="form-control"
                placeholder="Phone Number">
                    </ input>
            </div>

   
                
            <button 
            type="submit" className="btn btn-primary">
                Sign Up</button>
                <Link  className="nav-link" to="/login">Already have an account? Sign In</Link >
            </form>
    </div>
</AddItemContainer>
)}

export default Register

//MAIN CONTAINER
const AddItemContainer = styled.div`
    margin: 4rem auto;
    width: 32rem;

    h1 {
        font-weight: 900;;
        color: #1D2951;
    }

    .form-group {
        margin: 1rem auto;
    }

    .btn-primary {
        margin-top: 2rem;
        background:#02014b ;
        border: none;
        &:hover {
            background: #23387F;
        }
    }

    .message {
        font-weight: 900;
        color: tomato;
        padding: 1rem 1rem 1rem 0;
    }

    .label {
        color: #02014b 
    }
`;