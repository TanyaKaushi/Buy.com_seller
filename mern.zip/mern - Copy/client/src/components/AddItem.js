import React, {useState} from 'react';
import styled from 'styled-components';
import axios from 'axios';


export const AddItem = () => {
    const [name, setName] = useState("");
    const [description, setDescription] = useState("");
    const [price, setPrice] = useState("");
    const [message, setMessage] = useState("");
    const [fileName, setFileName] = useState("");

    const onChangeFile = e => {
        setFileName(e.target.files[0]);
    }


    const changeOnClick = e => {
       e.preventDefault();

    const formData = new FormData();

    formData.append("name", name);
    formData.append("description", description);
    formData.append("price", price);
    formData.append("itemImage", fileName);

       setName("");
       setDescription("");
       setPrice("");


       axios.post("/items/add", formData)
       .then((res) => setMessage(res.data))
       .catch((err) => {
           console.log(err);
       });
    };

    return (
     <AddItemContainer>
        <div className="container">
         <h1>Add New Item</h1>
         <span className="message">{message}</span>
            <form onSubmit={changeOnClick} encType="multipart/form-data">
            <div className="form-group">
                <label htmlFor="price" >Item Price</label>
                <input type="text" 
                value={price}
                onChange={e => setPrice(e.target.value)}
                className="form-control"
                placeholder="Item Price">
                    </ input>
            </div>

            <div className="form-group">
                <label htmlFor="name" >Name</label>
                <input type="text" 
                value={name}
                onChange={e => setName(e.target.value)}
                className="form-control" 
                placeholder="Item Name">

                </input>
            </div>

            <div className="form-group">
                <label htmlFor="description">Description</label>
                <textarea  
                value={description}
                onChange={e => setDescription(e.target.value)}
                className="form-control" rows="3">
                </textarea>
                </div>

                <div className="form-group">
                    <label htmlFor="file">Choose item image</label>
                    <input type="file" filename="itemImage" className="form-control-file"
                    onChange={onChangeFile}></input>
                </div>

            <button 
            type="submit" className="btn btn-primary">
                Add Item</button>
            </form>
    </div>
</AddItemContainer>
)}

export default AddItem

//MAIN CONTAINER
const AddItemContainer = styled.div`
    margin: 4rem auto;
    width: 32rem;

    h1 {
        font-weight: 900;;
        color: #1D2951;
    }

    .form-group {
        margin: 1rem auto;
    }

    .btn-primary {
        margin-top: 2rem;
        background:#02014b ;
        border: none;
        &:hover {
            background: #23387F;
        }
    }

    .message {
        font-weight: 900;
        color: tomato;
        padding: 1rem 1rem 1rem 0;
    }

    .label {
        color: #02014b 
    }
`;