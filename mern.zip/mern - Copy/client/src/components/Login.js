import React, {useState} from 'react';
import styled from 'styled-components';
import axios from 'axios';
import {Link} from "react-router-dom";


export const Login = () => {
    const [fname, setFname] = useState("");
    const [password, setPassword] = useState("");
    const [message, setMessage] = useState("");
 

    const changeOnClick = e => {
       e.preventDefault();

    const formData = new FormData();

    formData.append("fname", fname);
    formData.append("password", password);

       setFname("");
       setPassword("");


       axios.post("/login/add", formData)
       .then((res) => setMessage(res.data))
       .catch((err) => {
           console.log(err);
       });
    };

    return (
     <AddLoginContainer>
        <div className="container">
         <h1>Sign In</h1>
         <span className="message">{message}</span>
            <form onSubmit={changeOnClick} encType="multipart/form-data">
            <div className="form-group">
                <label htmlFor="fname" >First Name</label>
                <input type="text" 
                value={fname}
                onChange={e => setFname(e.target.value)}
                className="form-control"
                placeholder="First Name">
                    </ input>
            </div>

            <div className="form-group">
                <label htmlFor="password" >Password</label>
                <input type="text" 
                value={password}
                onChange={e => setPassword(e.target.value)}
                className="form-control" 
                placeholder="Password">

                </input>
            </div>


            <button 
            type="submit" className="btn btn-primary">
                <Link  className="nav-link" to="/itemlist">Sign In</Link >
                </button>
            </form>
    </div>
</AddLoginContainer>
)}

export default Login

//MAIN CONTAINER
const AddLoginContainer = styled.div`
    margin: 4rem auto;
    width: 32rem;

    h1 {
        font-weight: 900;;
        color: #1D2951;
    }

    .form-group {
        margin: 1rem auto;
    }

    .btn-primary {
        margin-top: 2rem;
        background:#02014b ;
        border: none;
        &:hover {
            background: #23387F;
        }
    }

    .message {
        font-weight: 900;
        color: tomato;
        padding: 1rem 1rem 1rem 0;
    }

    .label {
        color: #02014b 
    }
`;