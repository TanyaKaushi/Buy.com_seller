import React, {useState, useEffect} from "react";
import {Route} from "react-router-dom";
import axios from 'axios';
import './App.css';
import "bootstrap/dist/css/bootstrap.min.css";
import Header from './components/layout/header';
import Navbar from './components/layout/Navbar';
import Footer from './components/layout/Footer';
import Home from './components/Home';
import AddItem from './components/AddItem';
import EditItem from './components/EditItem';
import Item from './components/Item';
import ItemList from './components/ItemList';
import Register from './components/Register';
import Login from './components/Login';

function App() {
  const[posts, setPosts] = useState([]);
  useEffect(() => {
    axios.get('/items')
    .then(res => setPosts(res.data))
    .catch(error => console.log(error));
  });
  return (
    <div className="App">
      <Header/>
      <Navbar/>
      <Route exact path="/" render={() => <Home posts={posts}/>} /> 

      <Route 
      path="/itemlist" 
      render={(props) => <ItemList {...props} posts={posts}/>} />  

     <Route 
      path="/register" 
      render={(props) => <Register {...props} posts={posts}/>} />  

    <Route 
      path="/login" 
      render={(props) => <Login {...props} posts={posts}/>} />  
      
      <Route 
      path="/item/:id" 
      render={(props) => <Item {...props} posts={posts}/>} />        

      <Route 
      path="/update/:id" 
      render={(props) => <EditItem {...props} posts={posts}/>} />         

      <Route path="/add-item" component={AddItem} />      
      <Footer/>
      
    </div>
  );
}

export default App;
