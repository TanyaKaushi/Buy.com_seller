const express = require('express');
const Register = require('../models/register');

const router = express.Router();


//REQUEST ADD NEW SELLER
router.post("/add", (req,res) => {
    const newRegister = new Register({
        fname: req.body.fname,
        lname: req.body.lname,
        email: req.body.email,
        password:req.body.password,
        city: req.body.city,
        country: req.body.country,
        phone: req.body.phone
    });


    newRegister
    .save()
    .then(() => res.json("The seller register successfully"))
    .catch((err) => res.status(400).json(`Error: ${err}`));
});

module.exports = router;







