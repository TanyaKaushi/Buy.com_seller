const express = require('express');
const router = express.Router();
const Items = require('../models/items');
const multer = require('multer');


const storage = multer.diskStorage({
    destination: (req, file, callback) => {
        callback(null, "./client/public/uploads/");
    },
    filename: (req, file, callback) => {
        callback(null, file.originalname);
    }
})

const upload = multer ({storage: storage});

//REQUEST GET ALL ITEMS
router.get("/",  upload.single("itemImage"), (req, res) => {
    Items.find()
    .then((item) => res.json(item))
    .catch((err) => res.status(400).json(`Error : ${err}`));
});


//REQUEST ADD NEW ITEMS
router.post("/add", upload.single("itemImage"), (req,res) => {
    const newItem = new Items({
        name: req.body.name,
        description: req.body.description,
        price:req.body.price,
        itemImage: req.file.originalname,
    });


    newItem
    .save()
    .then(() => res.json("The new item posted successfully"))
    .catch((err) => res.status(400).json(`Error: ${err}`));
});


//REQUEST FIND ARTICLE BY ID
router.get('/:id', (req,res) => {
    Items.findById(req.params.id)
    .then(item => res.json(item))
    .catch(err => res.status(400).json(`Eror: ${err}`))
});

//REQUEST FIND ITEMS BY ID AND UPDATE
router.put("/update/:id", upload.single("itemImage"), (req,res) => {
    Items.findById(req.params.id)
    .then(item => {
        item.name = req.body.name;
        item.description = req.body.description;
        item.price = req.body.price;
        item.itemImage = req.file.originalname;

        item
        .save()
        .then(() => res.json("The item is update successfully"))
        .catch((err) => res.status(400).json(`Error: ${err}`));
    })

    .catch(err => res.status(400).json(`Error: ${err}`));
});
 


//REQUEST FIND ITEMS BY ID AND DELETE
router.delete("/:id", (req,res) => {
    Items.findByIdAndDelete(req.params.id)
    .then(() =>res.json("The article is deleted"))
    .catch(err => res.status(400).json(`Error: ${err}`));
})



module.exports = router;