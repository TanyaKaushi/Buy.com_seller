const express = require('express');
const Login = require('../models/login');

const router = express.Router();

//REQUEST ADD NEW SELLER
router.post("/add", (req,res) => {
    const newLogin = new Login({
        fname: req.body.fname,
        password:req.body.password,
        
    });


    newLogin
    .save()
    .then(() => res.json("The seller login successfully"))
    .catch((err) => res.status(400).json(`Error: ${err}`));
});

module.exports = router;







